#include<iostream>
using namespace std;

class location{
	int lon,lat;

public:

	location(){
		lon = 0;
		lat = 0;
		cout<<"default Constructor"<<endl;
	}

	location(int a, int b){
		lon = a;
		lat = b;
		cout<<"parameterized constructor"<<endl;
	}

	void display(){
		cout<<"longitude="<<lon<<endl<<"latitude="<<lat<<endl;
	}

	void * operator new(size_t byte){
		void *p;
		cout<<"inside overloaded new"<<endl;
		p= malloc (byte); 					
		if(p == NULL){
			cout<<"could not allocate memory"<<endl;
			// exit();
		}
		return p;
	}

	void  operator delete(void *p){
		cout<<"inside overloaded delete"<<endl;
		free(p);
	}
};

int main(){
	location l1,l2(2,5);
	l1.display();
	l2.display();

	location *loc = new location(4,6);
	loc->display();

	int *pt = new int;   //default new will be called
	delete(loc);
	return 0;

}
