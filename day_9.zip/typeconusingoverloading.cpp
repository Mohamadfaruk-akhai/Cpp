//basic to class type conversion using constructor
#include<iostream>
using namespace std;

class Time{
	int hour,min;
public:
	Time(){
		cout<<"default constructor"<<endl;
	}
	Time(int x){
		cout<<"inside param constructor\n";
		
	}
	Time operator = (int x)
	{
		cout<<"Inside operator overloading"<<endl;
		hour = x / 60;
		min = x % 60;
	}
	void display(){
		cout<<"hour="<<hour<<endl<<"min="<<min<<endl;
	}
};

int main(){
	int x=160;
	//Time T1(130) 
	Time T1;
	T1 = x ;
	T1.display();
	return 0;
}
