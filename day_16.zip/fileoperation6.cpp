#include<iostream>
#include<fstream>
using namespace std;

int main()
{
fstream fin,fout;
fin.open("hello.txt");
fout.open("hello1.txt");
char ch;
while(!fin.eof())
{
fin.get(ch);
fout.put(ch);
//fout<<ch; we can also copy data like this
}
cout<<"Copy Done:"<<endl;
fin.close();
fout.close();
return 0;
}
