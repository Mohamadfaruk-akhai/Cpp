#include<iostream>
#include<fstream>
using namespace std;

int main()
{
ifstream input;
string str;
int count =0;
input.open("hello.txt");

if(!input)
cout<<"The file cannot open"<<endl;
else
{
while(getline(input,str))
{
input>>str;count++;
}
}
cout<<"total lines:"<<count<<endl;
return 0;
}
