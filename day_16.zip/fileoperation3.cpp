#include<iostream>
#include<fstream>
using namespace std;

int main()
{
ifstream input;
string str,str2;
input.open("hello.txt");

if(!input)
cout<<"The file cannot open"<<endl;
else
{
while(!input.eof())
{
input>>str>>str2;
cout<<str<<'\t'<<str2<<endl;
}
}
return 0;
}
