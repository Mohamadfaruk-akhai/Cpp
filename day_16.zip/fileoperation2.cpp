#include<iostream>
#include<fstream>
using namespace std;

int main()
{
ifstream input;
string str;
input.open("hello.txt");

if(!input)
cout<<"The file cannot open"<<endl;
else
{
while(getline(input,str))
{
cout<<str<<endl;
}
}
return 0;
}
