// Constructor and Destructor Program
#include<iostream>
using namespace std;

class Distance{
public:
int feet;
int inch;

Distance()//Default COnstructor
	{
	feet=0;
	inch=0;
	cout << "Constructor called!"<<endl;
	}

Distance(int x,int y)//Parameterized Constructor
	{
	feet=x;
	inch=y;
	cout << "Param. Constructor called!"<<endl;
	}

Distance(Distance &obj)//Copy Constructor
	{
	feet=obj.feet;
	inch=obj.inch;
	cout << "Copy Constructor called!"<<endl;
	}

~Distance()//Destructor
	{
	cout << "Destructor called!"<<endl;
	}
};


//MAIN function
int main()
{
Distance d1;
Distance d2(3,8);
Distance d3(d2);
cout << d1.feet << " feet and " << d1.inch << " inches."<<endl;
cout << d2.feet << " feet and " << d2.inch << " inches."<<endl;
cout << d3.feet << " feet and " << d3.inch << " inches."<<endl;

return 0;
}
