//static variable and function

#include<iostream>
using namespace std;

class staticfun
{
  static int count; //declaring static variable, static variable is common for all object
  int co=0; // declaring normal variable
public:
  void getcount() // normal count function  
  {
    cout<<"count="<<co++<<endl; //return all time same value which are intilized to variable;
  }
  static void getc() //static count  function 
  {
    cout<<"value of count="<<count++<<endl; //static function only access static variable it is  same for all object that's why count is incremented every time. 	
    //cout<<co; //static function cannot access non static variable
  }
};

int staticfun::count; //by default value of this static count variable will be 0. we can assign any value to it.


int main()
{
  staticfun o1,o2,o3;
    o1.getcount();
  staticfun::getc(); // we can call static function like this without object
  o2.getcount();
  o2.getc();
  o3.getcount();
 staticfun::getc();
  return 0;
}
