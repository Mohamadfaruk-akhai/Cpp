#include<iostream>
using namespace std;
class XYZ; //forward declaration
//Abc class
class ABC 
{
	int a;
	public:
	void setdata()
	{
	a=10;
	}
	friend int add(ABC, XYZ);
};
// xyz class
class XYZ 
{
	int b;
	public:
	void setdata()
	{
	b=25;
	}
	friend int add(ABC , XYZ);
};

	int add(ABC objA, XYZ objB){
	return (objA.a + objB.b);
}
int main(){
ABC objA; XYZ objB;
objA.setdata(); objB.setdata();
cout<<"Sum: "<< add(objA, objB);
}
