#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<char> v(10);
	int i;
	vector<char>::iterator p;
	p=v.begin();
	i=0;
	while(p!=v.end())
	{
	*p=i+'a';
	p++;
	i++;
	}
	cout<<"Original contents:"<<endl;
	p=v.begin();
	while(p!=v.end())
	{
	cout<<*p<<" "<<endl;
	p++;
	}
	p=v.begin();
	while(p!=v.end())
	{
	*p=toupper(*p);
	p++;
	}
	v.insert(p,'W');
	cout << "This" << *p << endl;
	//p=v.end();
	p=p-2;
	v.erase(p);
	cout<<"Modified Contents:"<<endl;
	p=v.begin();
	while(p!=v.end())
	{
	cout<<*p<<" "<<endl;
	p++;
	}
return 0;
}
