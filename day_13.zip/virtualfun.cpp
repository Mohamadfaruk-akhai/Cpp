#include<iostream>
using namespace std;
class base
{
public:
virtual void show()
{
cout<<"base=\n";
}
};
class derived1 : public base{
public:
void show()
{
cout<<"derived1\n";
}
};
class derived2 : public base{
public:
void show()
{
cout<<"derived2\n";
}
};
int main()
{
base *ptr;
derived1 d1;
derived2 d2;
ptr=&d1;
//ptr->showbase();
ptr->show();
ptr=&d2;
ptr->show();
return 0;
}
