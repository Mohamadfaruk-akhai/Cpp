#include<iostream>
using namespace std;
class shape
{
protected:
	float x;
public:
	void getdata()
	{
	cin>>x;
	}
	virtual float calculateArea() = 0;
};
class square:public shape
{
public:
	float calculateArea()
	{
	return x*x;
	}
};
class circle:public shape
{
public:
	float calculateArea()
	{
	return 3.14*x*x;
	}
};
int main()
{
	shape *ptr;
	//shape s;
	square s1;
	circle c1;
	ptr=&s1;
	cout<<"Enter the length to calculate the area of square"<<endl;
	ptr->getdata();
	cout<<"Area of square are "<<ptr->calculateArea()<<endl;
	ptr=&c1;
	cout<<"Enter the length to calculate the area of circle"<<endl;
	ptr->getdata();
	cout<<"Area of circle are "<<ptr->calculateArea();
return 0;
}
