#include<iostream>
using namespace std;
class base
{
public:
virtual void fun()
{
cout<<"base virtual\n";
}
};
class derived1 : public base{
public:
void fun()
{
cout<<"derived virtual\n";
}
};
class derived2 : public base{
public:
void display()
{
cout<<"derived2 virtual\n";
}
};
int main()
{
//base *ptr;
derived1 d1;
derived2 d2;
//ptr=&d1;
//ptr->showbase();
d2.fun();
//ptr=&d2;
//ptr->fun();
return 0;
}
