#include<iostream>
using namespace std;
class base
{
public:
int b;
void show()
{
cout<<"\nb="<<b;
}
};
class derived : public base{
public:
int d;
void show()
{
cout<<"\nd="<<d;
}
};
int main()
{
base *bptr;
base b;
derived d;
bptr=&b;
cout<<"\nBase class pointer assign address of base clas object";
bptr->b=100;
//ptr->showbase();
bptr->show();
bptr=&d;
bptr->b=200;
cout<<"\nBase class pointer assign address of derived clas object";
bptr->show();
derived *dptr;
dptr=&d;
cout<<"\nderived class pointer assign address of derived clas object";
dptr->b=300;
bptr->show();
return 0;
}
