#include<iostream>
using namespace std;
class unopov{
	int a,b,c;
	public:
	unopov()
	{
		a=b=c=0;	
	}
	unopov(int d,int e,int f)
	{
		a=d;
		b=e;
		c=f;	
	}
	void display()
	{
		cout<<"a= "<<a<<" b= "<<b<<" c= "<<c<<endl;	
	}
	friend void operator -(unopov &ob);
	friend void operator --(unopov &ob);
	friend void operator ++(unopov &ob);
};
void operator -(unopov &ob){
ob.a=-ob.a;
ob.b=-ob.b;
ob.c=-ob.c;
}
void operator --(unopov &ob){
ob.a=--ob.a;
ob.b=--ob.b;
ob.c=--ob.c;
}
void operator ++(unopov &ob){
ob.a=++ob.a;
ob.b=++ob.b;
ob.c=++ob.c;
}
int main()
{
unopov u1(4,6,8);
u1.display();
-u1;
u1.display();
--u1;
u1.display();
++u1;
u1.display();
return 0;
}
