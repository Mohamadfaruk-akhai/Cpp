#include<iostream>
using namespace std;
int main()
{
	float *ptr= new float;
	*ptr=50;
	cout<<"Value= "<<*ptr<<endl;
	cout<<"Address= "<<ptr<<endl;
	cout<<"Sizeof actual value= "<<sizeof(*ptr)<<endl;
	cout<<"Sizeof ptr value= "<<sizeof(ptr)<<endl;
	cout<<"Address of ptr= "<<&ptr<<endl;
	return 0;
}
