#include<iostream>
using namespace std;
class prepos{
	int a;
	public:
	prepos()
	{
		a=0;	
	}
	prepos(int d)
	{
		a=d;
	}
	void operator ++();
	void operator ++(int);
	void operator --();
	void operator --(int);
};
void prepos::operator ++(){
++a;
cout<<"pre-increment:"<<a<<endl;

}
void prepos::operator ++(int){
a++;
cout<<"post-increment:"<<a<<endl;

}
void prepos::operator --(){
--a;
cout<<"pre-decrement:"<<a<<endl;

}
void prepos::operator--(int){
a--;
cout<<"post-decrement:"<<a<<endl;

}
int main()
{
prepos p1(4);
p1++;
++p1;
--p1;
p1--;
return 0;
}
