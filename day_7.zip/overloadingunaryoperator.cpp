#include<iostream>
using namespace std;
class unopov{
	int a,b,c;
	public:
	unopov()
	{
		a=b=c=0;	
	}
	unopov(int d,int e,int f)
	{
		a=d;
		b=e;
		c=f;	
	}
	void display()
	{
		cout<<"a= "<<a<<" b= "<<b<<" c= "<<c<<endl;	
	}
	void operator -();
	void operator --();
	void operator ++();
};
void unopov::operator -(){
a=-a;
b=-b;
c=-c;
}
void unopov::operator --(){
a=--a;
b=--b;
c=--c;
}
void unopov::operator ++(){
a=++a;
b=++b;
c=++c;
}
int main()
{
unopov u1(4,6,8);
u1.display();
-u1;
u1.display();
--u1;
u1.display();
++u1;
u1.display();
return 0;
}
