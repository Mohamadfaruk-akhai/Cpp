#include<iostream>
#include<stdio.h>
using namespace std;
class A{
public:
	int i=0,j=0   ,k,l,m;
	A(){
		cout<<"inside constructor"<<endl;
		i=0;
		j=10;
	}

	~A(){
		cout<<"inside destructor"<<endl;
	}
};

int main(){
	int *p1;
	A a1,*a2,*a3,*d;
	p1=new int;

	a2 = new A [5];
	a3 = new A;
	a3 = NULL;
	cout<<"Size of a1="<<sizeof(a1)<<"  size of ptr="<<sizeof(p1)<<endl;
	delete p1;
	delete[] a2;
	delete a3;
	char *c = (char *) malloc(sizeof(char)*5);
	d= (A *) malloc(sizeof(A)*5);
	cout<<"----------------------"<<endl;
	delete c;
	//delete d; If we delete oject like this destructor is called
	free (d); //In this destructor in not called 
	cout<<"size of a1="<<sizeof(a1)<<" size of  ptr="<<sizeof(p1)<<endl;
	return 0;
}
