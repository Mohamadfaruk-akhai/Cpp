#include<fstream>
#include<iostream>
using namespace std;
class student{
	public:
	int roll;
	char name[25];
	float marks;
	void getdata()
	{
	cout<<"enter roll no and name"<<endl;
	cin>>roll>>name;
	cout<<"Marks"<<endl;
	cin>>marks;
	}
	void Addrecord()
	{
	fstream file;
	student stu;
	file.open("student.dat",ios::app|ios::binary);
	stu.getdata();
	file.write((char*)&stu,sizeof(stu));
	file.close();
	}
	};
int main()
{
student s1;
char ch='n';
do{
s1.Addrecord();
cout<<"Want Add more?(y/n)"<<endl;
cin>>ch;
}while(ch=='y');
return 0;
}
