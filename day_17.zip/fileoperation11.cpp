#include<iostream>
#include<fstream>
using namespace std;
int main()
{
ofstream outfile;
outfile.open("helloworld.txt");
outfile<<"This is my file"<<endl;
long pos = outfile.tellp();
outfile.seekp(pos+6);
outfile<<"Again in my file";
outfile.close();
cout<<"Done!!";
return 0;
}
