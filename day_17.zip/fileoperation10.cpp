#include<fstream>
#include<iostream>
using namespace std;
class student{
	public:
public:
	int roll;
	char name[25];
	float marks;
	void getdata()
	{
	cout<<"enter roll no and name"<<endl;
	cin>>roll>>name;
	cout<<"Marks"<<endl;
	cin>>marks;
	}
	void display()
	{
	fstream file;
	student stu;
	file.open("student.dat",ios::in|ios::binary);
	file.read((char*)&stu,sizeof(stu));
	cout<<"Roll "<<stu.roll<<" Name "<<stu.name<<" Mark: "<<stu.marks<<endl;
	file.close();
	}
};
int main()
{
student s1;
s1.getdata();
s1.display();
return 0;
}
