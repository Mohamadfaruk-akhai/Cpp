#include<iostream>
using namespace std;
class base
{
public:
void showbase()
{
cout<<"BAse"<<endl;
}
};
class derived : public base{
public:
void showderived()
{
cout<<"derived"<<endl;
}
};
int main()
{
base *ptr;
base b;
derived d;
ptr=&b;
ptr->showbase();
ptr=&d;
ptr->showbase();
//ptr->showderived();
((derived *)ptr)->showderived();
return 0;
}
