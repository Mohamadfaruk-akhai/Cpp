#include<iostream>
using namespace std;
class A{
int a,b;
public:
void input(int a,int b){
this->a=a+b;
this->b=a-b;
}
void output(){
cout<<"a= "<<a<<endl;
cout<<"b= "<<b<<endl;
}
};
int main()
{
A a1;
int a=5,b=10;
a1.input(a,b);
a1.output();
return 0;
}
