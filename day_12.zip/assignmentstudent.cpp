#include<iostream>
using namespace std;

class Student
{
	int marks;
	char name[10];
public:
	int roll_no;
	void getdata()
	{
		cout<<"enter roll number: ";
		cin>>roll_no;
		cout<<"enter name: ";
		cin>>name;
		cout<<"enter marks: ";
		cin>>marks;
	}
	void printdata()
	{
		cout<<"Roll no.: "<<roll_no<<endl<<"Name: "<<name<<endl<<"Marks: "<<marks<<endl;
	}
};

int main()
{
	Student obj[3];
	Student *ptr;
	ptr=obj;
	for(int i=0;i<3;i++)
	{
		ptr->getdata();
		ptr++;
	}

	ptr=obj;

	cout<<"Student Information"<<endl;
	for(int i=0;i<3;i++)
	{
		ptr->printdata();
		ptr++;
	}
}
