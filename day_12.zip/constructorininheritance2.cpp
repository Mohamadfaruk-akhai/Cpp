#include<iostream>
using namespace std;
class Base1{
protected:
int i;
public:
Base1(int x){
i=x;
cout<<"BAse1 paramizerized constructor"<<endl;
}
~Base1(){
cout<<"Destructing base1"<<endl;
}
}; 
class Base2{
protected:
int j;
public:
Base2(int x){
j=x;
cout<<"BAse2 paramizerized constructor"<<endl;
}
~Base2(){
cout<<"Destructing base2"<<endl;
} 
}; 
class Derived: public Base1, public Base2 {
int k;
public:
Derived(int x, int y ,int z):Base1(x), Base2(y){
k=z;
cout<<"derived paramizerized constructor"<<endl;
}
~Derived(){
cout<<"Destructing Derived"<<endl;
}
void show(){
cout<<i<<" "<<j<<" "<<k<<" "<<endl;
}
}; 
int main()
{
Derived d1(10,15,20);
d1.show();
return 0;
}
