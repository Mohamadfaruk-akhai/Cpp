#include <iostream>

using namespace std;
class person
{
    public:
    void walk()
    {
        cout<<"walking"<<endl;
    }
     void talk()
    {
        cout<<"talking"<<endl;
    }
     void eat()
    {
        cout<<"eating"<<endl;
    }
};
class doctor:virtual public  person
{
    public:
    void diagones()
    {
        cout<<"doing diagones"<<endl;
    }
    
};
class footballer: virtual public person
{
    public:
    void playfootball()
    {
        cout<<"playing Football"<<endl;
    }
};
class businessman:public footballer, public doctor
{
    public:
    void runbusiness()
    {
        cout<<"Running business"<<endl;
    }
};
int main()
{
    doctor d1;
    footballer f1;
    businessman b1;
    d1.walk();
    f1.talk();
    b1.talk(); // now it's working becuase of virtual keyword

    b1.diagones();
    d1.diagones();
    b1.playfootball();
    f1.playfootball();
    b1.runbusiness();
    return 0;
}
