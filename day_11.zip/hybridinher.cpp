#include <iostream>
using namespace std;
class person
{
    public:
    void display1()
    {
        cout<<"person class"<<endl;
    }
};
class doctor:public person
{
    public:
    void display2()
    {
        cout<<"doctor class"<<endl;
    }
};
class footballer:public person
{
    public:
    void display3()
    {
        cout<<"footballer class"<<endl;
    }
};
class businessman:public footballer, public doctor
{
    public:
    void display4()
    {
	//display1(); this will create ambiguity
	footballer::display1(); // we can access display1 with the help of scope resolution
        cout<<"businessman class"<<endl;
    }
};
int main()
{
    businessman b1;
    b1.display2(); //in hybrid inheritance we can't access property of person class using business class object
    b1.display3();
    b1.display4();
    //b1.display1();
    return 0;
}
