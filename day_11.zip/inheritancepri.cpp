#include<iostream>
using namespace std;
class base
{
int i,j;
public:
void set(int a, int b){
i=a; j=b;
}
void show(){
cout<<i<<" "<<j;
}
};
class derived : private base //here acees modifier is private when we inheriting so all the public function of base class will become private into derived class so if we try to call function of base class with derived class object then it will throw error becuse of private access modifier we can call it from main function with the help of base class object.
{
int k;
public:
derived (int x){
k=x;
}
void showk()
{
cout<<k;
}
};
int main()
{
derived ob(5);
//ob.set(1,2); becuase of base is inherited privately we can't call the set and show fun becuase they are private in derived and inaccessible in main function
//ob.show();
ob.showk();
return 0;
}
