#include<iostream>
using namespace std;
class base
{
protected:
int i,j;
public:
void set(int a, int b){
i=a; j=b;
}
void show(){
cout<<i<<" "<<j<<endl;
}
};
class derived : private base //here acees modifier is private when we inheriting so all the public and protected function and variable of base class will become private into derived class.
{
int k;
public:
void setk()
{
k=i*j; // we can access i and j in this as they was protected in base class.
}
void showk()
{
cout<<k<<endl;
}
};
class derived1 : public derived
{
int m;
public:
void setm(){
//m=i-j; here we can't do like this as i and j become private in derived class so now they are inaccessible in derived1.
}
void showm(){
cout<<m<<endl; 
}
};
int main()
{
derived ob1;
derived1 ob2;
ob1.set(10,12); //error
ob1.show(); //error
ob2.setk();
ob2.showk();
return 0;
}
