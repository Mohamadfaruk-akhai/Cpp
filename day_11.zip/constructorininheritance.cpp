#include<iostream>
using namespace std;
class Base {
int x;
public:
Base(){
cout<<"BAse default constructor"<<endl;
}
Base(int i){
cout<<"BAse paramiterized constructor"<<endl;
}
~Base(){
cout<<"BAse default destructor"<<endl;
}
}; 
class Derived: public Base {
int x;
public:
Derived(){
cout<<"Derived default constructor"<<endl;
}
Derived(int i){
cout<<"Derived parameterized constructor"<<endl;
}
~Derived(){
cout<<"Derived default destructor"<<endl;
}
}; 
int main()
{
Base b;
Derived d1;
Derived d2(100);
return 0;
}
