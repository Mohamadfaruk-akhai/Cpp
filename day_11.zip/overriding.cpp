#include<iostream>
using namespace std;
class parent
{
public:
void display(){
cout<<"This is parent class"<<endl;
}
};
class child:public parent
{
public:
void display(){
cout<<"This is child class"<<endl;
}
};
int main()
{
child c;
c.display();
c.parent::display();
return 0;
}
