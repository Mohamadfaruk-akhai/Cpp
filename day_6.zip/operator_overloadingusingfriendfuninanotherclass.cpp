#include<iostream>
using namespace std;
class B;
class A{
    int x,y;
    public:
    A(){
        x=0;
        y=0;
    }
    A(int a,int b){
        x=a;
        y=b;
    }
    void display(){
        cout <<"Value is: "<< x << "   " << y << endl;
    }
    friend A operator+ (A ob1,B ob2);
    friend A operator- (A ob1,B ob2);

};

class B{
    int p,q;
    public:
    
    B(){
        p=0;
        q=0;
    }
    B(int a,int b){
        p=a;
        q=b;
    }
    void display(){
        cout << "Value is: "  << p << "   " << q << endl;
    }
    friend A operator+(A ob1,B ob2);
    friend A operator- (A ob1,B ob2);
};

A operator+ (A ob1,B ob2){
        A temp;
        temp.x=ob1.x + ob2.p;//error here
        temp.y=ob1.y + ob2.q;//error here
        return temp;
    }
A operator- (A ob1,B ob2){
        A temp;
        temp.x=ob1.x - ob2.p;//error here
        temp.y=ob1.y - ob2.q;//error here
        return temp;
    }


//MAIN
int main(){
    A obj1(6,7);
    B obj2(4,5);
    A obj3;
    obj3=obj1+obj2;
    obj1.display();
    obj2.display();
    cout<<"After Addition value is: ";
    obj3.display();
    obj3=obj1-obj2;
    cout<<"After Subtraction value is: ";
    obj3.display();
    return 0;
    
}
