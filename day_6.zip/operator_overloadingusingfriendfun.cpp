// operator overloading usinf friend function

#include<iostream>
using namespace std;

class Complex
{
  int real,img;
  public:

  Complex() //default constructor
  {
    real=img=0;
  }

  Complex(int r,int i) //parameterized constructor
  {
    real=r;
    img=i;
  }

  void display() //display values
  {
    cout<<"The value for real part is: "<<real<<" imaginary part is: "<<img<<endl<<endl;
  }
	friend Complex operator + (Complex,Complex);    
	friend Complex operator - (Complex,Complex);
	friend Complex operator * (Complex,Complex);    
	friend Complex operator / (Complex,Complex);
    
};

Complex operator +(Complex obj1,Complex obj2)
  {
    Complex temp;
    temp.real=obj1.real+obj2.real; 
    temp.img=obj1.img+obj2.img;
    return temp;
  }
Complex operator -(Complex obj1,Complex obj2)
  {
    Complex temp;
    temp.real=obj1.real-obj2.real+10; 
    temp.img=obj1.img-obj2.img+10;
    return temp;
  }
Complex operator *(Complex obj1,Complex obj2)
  {
    Complex temp;
    temp.real=obj1.real*obj2.real; 
    temp.img=obj1.img*obj2.img;
    return temp;
  }
Complex operator /(Complex obj1,Complex obj2)
  {
    Complex temp;
    temp.real=obj1.real/obj2.real; 
    temp.img=obj1.img/obj2.img;
    return temp;
  }

int main()
{
  	Complex c1(4,3),c2(15,12),c3;
  	c1.display();
  	c2.display();
  	c3.display();
 	c3 = c1+c2; 
  	cout<<"after doing Addition: "<<endl;
  	c3.display();
  	c3 = c1-c2; // subtracting two object
	//  c3=c1.operator - (c2);
  	cout<<"after doing substraction: "<<endl;
  	c3.display();
	c3 = c1*c2; 
  	cout<<"after doing Multiplication: "<<endl;
  	c3.display();
	c3 = c1/c2; 
  	cout<<"after doing division: "<<endl;
  	c3.display();
}
