#include<iostream>
using namespace std;
class complex{
	int real,img;
	public:
	complex(){
	real=0;
	img=0;
	}
	complex(int a,int b){
	real=a;
	img=b;
	}
	void display(){
	cout<<"real value is "<<real<<" imaginary value is "<<img<<endl;
	}
	//overloading the + operator
	complex operator +(complex obj)
	{
		complex t;
		t.real = real+obj.real; // it will work like c1.real + c2.real
		t.img = img + obj.img;	// it will work like c1.img + c2.img
		return t;
	}
	//overloading the - operator
	complex operator -(complex obj)
	{
		complex t;
		t.real = real-obj.real;
		t.img = img - obj.img;
		return t;
	}
	//overloading the * operator
	complex operator *(complex obj)
	{
		complex t;
		t.real = real*obj.real;
		t.img = img * obj.img;
		return t;
	}
	//overloading the / operator
	complex operator /(complex obj)
	{
		complex t;
		t.real = real/obj.real;
		t.img = img / obj.img;
		return t;
	}
	//overloading the % operator
	complex operator %(complex obj)
	{
		complex t;
		t.real = real%obj.real;
		t.img = img % obj.img;
		return t;
	}
	//overloading the = operator
	complex operator =(complex obj)
	{
		
		real = obj.real;
		img =  obj.img;
		return t;
	}
	//overloading the - operator
	complex operator -(complex obj)
	{
		complex t;
		t.real = -real;
		t.img = -img;
		return t;
	}
	//overloading the ++operator
	complex operator ++(complex obj)
	{
		complex t;
		t.real = real+1;
		t.img = img+1;
		return t;
	}
	//overloading the ++operator
	complex operator --(complex obj)
	{
		complex t;
		t.real = real-1;
		t.img = img-1;
		return t;
	}

};

int main()
{
	complex c1(2,4),c2(10,12),c3;
	c1.display();
	c2.display();
	c3=c1+c2;
	cout<<"after doing Addition ";
	c3.display();
	cout<<"after doing Addition ";
	c3=c2. operator +(c2);
	c3.display();
	c3=c1-c2;
	cout<<"after doing subtraction ";
	c3.display();
	c3=c1*c2;
	cout<<"after doing Multiplication ";
	c3.display();
	c3=c1/c2;
	cout<<"after doing division ";
	c3.display();
	c3=c1%c2;
	cout<<"after doing Reminder ";
	c3.display();
	c3=c2;
	cout<<"after doing Assignment ";
	c3.display();
	c3=-c2;
	cout<<"after doing negation ";
	c3.display();
	c3=c2--;
	cout<<"after doing decrement ";
	c3.display();
	c3=c2++;
	cout<<"after doing Increment ";
	c3.display();
}
