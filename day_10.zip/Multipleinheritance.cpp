#include <iostream>

using namespace std;
class Liquid
{
   public:
    void liq()
    {
        cout<<"liquid"<<endl;
    }
};
class fuel
{
    public:
    void fue()
    {
        cout<<"Fuel"<<endl;
    }
};
class petrol: public Liquid, public fuel
{
    public:
    void pet()
    {
        cout<<"petrol"<<endl;
    }
};
int main()
{
    Liquid l1;
    fuel f1;
    petrol p1;
    l1.liq();
    f1.fue();
    p1.liq();
    p1.fue();
    p1.pet();
    return 0;
}

