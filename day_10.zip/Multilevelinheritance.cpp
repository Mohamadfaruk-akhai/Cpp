#include <iostream>

using namespace std;
class person
{
    public:
    int age,height,weight;
    void walk()
    {
        cout<<"walking"<<endl;
    }
     void talk()
    {
        cout<<"talking"<<endl;
    }
     void eat()
    {
        cout<<"eating"<<endl;
    }
};
class doctor:public person
{
    public:
    void diagones()
    {
        cout<<"doing diagones"<<endl;
    }
};
class dentist:public doctor
{
    public:
    void op()
    {
        cout<<"can do operation of teeth"<<endl;
    }
};
class cricketer:public dentist
{
    public:
    void playcricket()
    {
        cout<<"playing cricket after work hours"<<endl;
    }
};
int main()
{
    doctor d1;
    dentist d11;
    cricketer c1;
    d1.walk();
    c1.talk();
    d11.eat();
    d11.diagones();
    c1.playcricket();
    c1.op();
    return 0;
}

