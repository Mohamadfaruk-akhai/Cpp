#include <iostream>

using namespace std;
class person
{
    public:
    int age,height,weight;
    void walk()
    {
        cout<<"walking"<<endl;
    }
     void talk()
    {
        cout<<"talking"<<endl;
    }
     void eat()
    {
        cout<<"eating"<<endl;
    }
};
class doctor:public person
{
    public:
    void diagones()
    {
        cout<<"doing diagones"<<endl;
    }
};
int main()
{
    doctor d1;
    d1.walk();
    d1.talk();
    d1.eat();
    d1.diagones();
    return 0;
}

