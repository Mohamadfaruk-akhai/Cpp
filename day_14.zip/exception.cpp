#include <iostream>
using namespace std;

int main ()
{
int n1, n2;
float ans;
cout << "enter n1 and n2: " << endl;
cin >> n1 >> n2;
try
{
if (n2==0 )
{
throw n2;
}
else
{
ans = (float) n1 / n2;
cout << "Ans " << ans<<endl;
}
}
catch(int x)
{
cout<<"can't divide by "<<x<<endl;
}
cout<<"end of program";
return 0;
}
