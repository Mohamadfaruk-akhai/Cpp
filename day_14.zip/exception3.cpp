#include <iostream>

using namespace std;

int main()
{
    int n1;
    cout << "enter the number 1: ";
    cin >> n1;

    try
    {
        try
        {
            if (n1 == 1)
            {
                throw n1;
            }
            else if (n1 == 2)
            {
                throw 'a';
            }
            else if (n1 == 3)
            {
                throw 4.5f;
            }
        }
        catch (int x)
        {
            cout << "throwing integer exception " <<x<<endl;
        }

        catch (char x)
        {
            cout << "throwing character exception " <<x<<endl;
        }

        catch (float x)
        {
            cout << "throwing float exception " <<x<<endl;
        }

        catch (...)
        {
            cout << "unknown exception" << endl;
        }
    }
	catch(int x)
	{
	
	}
	
    return 0;
}
