#include<iostream>
#include<list>
using namespace std;
int main()
{
	list<int> lst1,lst2;
	int i;
	for(i=0;i<10;i+=2)
		lst1.push_back(rand()%10);
	for(i=0;i<10;i+=2)
		lst2.push_back(rand()%10);
		cout<<"contents lst1:"<<endl;
	list<int>::iterator p;
	p=lst1.begin();
	while(p!=lst1.end())
	{
	cout<<*p<<" ";
	p++;
	}
	cout<<endl<<"contents lst2:"<<endl;
	p=lst2.begin();
	while(p!=lst2.end())
	{
	cout<<*p<<" ";
	p++;
	}
	cout<<endl;
	lst1.merge(lst2);
	cout<<"After mergin lst1:"<<endl;
	p=lst1.begin();
	while(p!=lst1.end())
	{
	cout<<*p<<" ";
	p++;
	}
	/*lst2.sort();
	cout<<endl<<"After sorting lst2:"<<endl;
	p=lst2.begin();
	while(p!=lst2.end())
	{
	cout<<*p<<" ";
	p++;
	}*/
return 0;
}
