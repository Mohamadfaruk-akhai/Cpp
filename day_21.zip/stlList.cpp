#include<iostream>
#include<list>
using namespace std;
int main()
{
	list<int> lst;
	int i;
	for(i=0;i<10;i++)
		lst.push_back(i);
		cout<<"Size="<<lst.size()<<endl;
		cout<<"contents:"<<endl;
	list<int>::iterator p;
	p=lst.begin();
	while(p!=lst.end())
	{
	cout<<*p<<" ";
	p++;
	}
	p=lst.begin();
	while(p!=lst.end())
	{
	*p=*p+100;
	p++;
	}
	cout<<endl<<"Modified Contents:"<<endl;
	p=lst.begin();
	while(p!=lst.end())
	{
	cout<<*p<<" ";
	p++;
	}
	p=lst.end();
	p--;
	cout<<endl;
	while(p!=lst.begin())
	{
	cout<<*p<<" ";
	p--;
	}
return 0;
}
