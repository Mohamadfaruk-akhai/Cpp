#include<iostream>
#include<map>
#include<string.h>
using namespace std;
class name
{
	char str[20];
	public:
		name(){
		strcpy(str,"");}
	name(char *s){strcpy(str,s);}
	char *get() {return str;}
};
bool operator<(name a,name b)
{
	return strcmp(a.get(),b.get())<0;
}
class phonenum
{
	char str[20];
	public:
		phonenum(){
		strcpy(str,"");}
	phonenum(char *s){strcpy(str,s);}
	char *get() {return str;}
};
int main()
{
	map<name,phonenum> directory;
	directory.insert(pair<name,phonenum>(name("faruk"),phonenum("12345678910")));
	directory.insert(pair<name,phonenum>(name("M.faruk"),phonenum("1289103451")));
	directory.insert(pair<name,phonenum>(name("faruk1"),phonenum("12345678932")));
	char str[20];
	cout<<"Enter name:"<<endl;
	cin>>str;
	map<name,phonenum>::iterator p;
	p=directory.find(name(str));
	if(p!=directory.end())
	cout<<"Phone No. "<<p->second.get()<<endl;
	else
	cout<<"Key not in map"<<endl;
return 0;
}

