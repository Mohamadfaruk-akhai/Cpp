#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
char str[]= "I love c++ programing";
vector<char>v,v2(30);
int i;
for(i=0;str[i];i++)
	v.push_back(str[i]);
cout<<"Input sequence:"<<endl;
for(i=0;i<v.size();i++)
cout<<v[i];
cout<<endl;
remove_copy(v.begin(),v.end(),v2.begin(),' ');
cout<<"Result After removing space:"<<endl;
for(i=0;i<v2.size();i++)
cout<<v2[i];
cout<<endl;
return 0;
}
