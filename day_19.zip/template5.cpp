#include<iostream>
using namespace std;
template<class T>
void fun(T x)
{
	static int i=10;
	cout<<++i<<endl;
}
int main()
{
fun<int>(1);
fun<double>(10.1);
fun(2);
fun(2.2);
return 0;
}
