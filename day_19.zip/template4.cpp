#include<iostream>
using namespace std;
template <typename T>
T sum(T n1,T n2)
{
	T rs;
	rs=n1+n2;
	return rs;
}
template <typename T,typename U>
T sum(T n1,U n2)
{
	T rs;
	rs=n1+n2;
	return rs;
}
void sum(int a,int b,int c)
{
cout<<"Sum of int:"<<a+b<<endl;
}
int main()
{
	int a=10,b=20,c=30;
	double A=20.5,B=30.7;
	cout<<"Sum:"<<sum(a,b)<<endl;
	cout<<" Sum:"<<sum(A,B)<<endl;
	cout<<" Sum:"<<sum(a,B)<<endl;
return 0;
}
