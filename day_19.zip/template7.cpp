#include<iostream>
using namespace std;
template <typename T>
void swap(T &n1,T &n2)
{
	cout<<"Inside template Swap."<<endl;
	T temp;
	temp=n1;
	n1=n2;
	n2=temp;
	
}
void swap(int &n1,int &n2)
{
	int temp;
	temp=n1;
	n1=n2;
	n2=temp;
	cout<<"Inside specialization Swap."<<endl;
}
int main()
{
	int a=10,b=20;
	char A[10]="faruk",B[10]="Rahul";
	swap1(a,b);
	cout<<"value after swap a="<<a<<" b="<<b<<endl;
	swap1(A,B);
	cout<<"value after swap A="<<A<<" B="<<B<<endl;
return 0;
}
