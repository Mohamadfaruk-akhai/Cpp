#include<iostream>
#include<exception>
using namespace std;
int main()
{
try{
int *myarr=new int[1000000000000];

}
catch(exception &e){
cout<<"std exception"<<e.what()<<endl;
}
cout<<"End of program";
return 0;
}
