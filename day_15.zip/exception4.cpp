#include <iostream>
using namespace std;
class test
{
int x;
public:
void read()
{
cout<<"Enter a number=";
cin>>x;
}
class Even {};
class Odd{};
void check(){
if(x%2==0)
throw Even{};
else
throw Odd{};
}
};
int main(){
test t;
t.read();
try
{
t.check();
}

catch (test:: Even)
{
cout << "Number is even " <<endl;
}
catch (test:: Odd)
{
cout << "Number is odd " <<endl;
}
cout << "end of the program " << endl;
return 0;
}
