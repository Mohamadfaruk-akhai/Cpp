#include <iostream>
using namespace std;
void Demo() throw(int,double)
{
int n=2;
if (n==1)
{
throw n;
}
else if(n==2)
{
throw 'e';
}
else if(n==3)
{
throw 4.5;
}
}
int main(){
try
{
Demo();
}
catch (int n)
{
cout << "Exception int  caught " <<endl;
}
catch (double n)
{
cout << "Exception double  caught " <<endl;
}
cout << "end of the program " << endl;
return 0;
}
