#include<iostream>
using namespace std;

class calculator
{
 //private:
  public:
	int i1,i2;

  void set(int a,int b)
  {
    i1=a;
    i2=b;
  }
//public:
  int add(calculator c1, calculator c2);
//  {
  //  return i1+i2;
  //}
  calculator sub(calculator c1, calculator c2)
  {
    calculator c;
    c.i1 = c1.i1-c2.i1;
    c.i2 = c2.i2-c2.i1;
    return c;
  }
  int mul()
  {
    return i1*i2;
  }
  int div()
  {
    return i1/i2;
  }
  int mod()
  {
    return i1%i2;
  }

};

int calculator :: add(calculator c1, calculator c2)
  {
    return c1.i1+c2.i1;
  }

int main()
{
  int n1,n2,c;
  cout<<"Which operation you want to perform?"<<endl;
  cout<<"1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Modulo\n";
  cout<<"Enter your choice: ";
  cin>>c;
  cout<<"Enter two numbers: ";
  cin>>n1>>n2;
  
  calculator obj,obj1,obj2,obj3;
  obj.set(n1,n2);
  obj1.set(n1,n2);
  obj2.set(n2,n1);

 // cout<<obj3<<endl;

  switch(c)
  {
    case 1:
      cout<<"Addition is: "<<obj.add(obj1,obj2)<<endl;
      break;
    case 2:
      obj3=obj.sub(obj1,obj2);
      cout<<"Subtraction is: "<<obj3.i1<<endl<<obj3.i2<<endl;
      break;
    case 3:
      cout<<"Multiplication is: "<<obj.mul()<<endl;
      break;  
    case 4:
      cout<<"Division is: "<<obj.div()<<endl;
      break;
    case 5:
      cout<<"Modulo is: "<<obj.mod()<<endl;
      break;
  }
  return 0;
}
/* So in this program first i have created simple calculator. then i try to make variable private but they so me error becuase we can't use private variables outside the class then i have  created member function add outside the class with the help of :: operator. then i have passed object as an argument in function and the last i created function who can return object.*/
