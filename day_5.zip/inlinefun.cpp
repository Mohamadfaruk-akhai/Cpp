#include<iostream>
using namespace std;
inline int cube(int a) // inline function defination
{
	return a*a*a;
}
int main()
{
	int n;
	cin>>n;
	cout<<"Cube of the value:"<<n<<" is "<<cube(n);
}
/*
when we have to use the function which has not to much statement in function body then it is better to use inline function because if we use simple function it take much time to creating stack and all those stuff but if we use inline function it will directly execute the statement.*/
