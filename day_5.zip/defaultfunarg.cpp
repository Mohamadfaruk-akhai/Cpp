#include<iostream>
using namespace std;
int mul(int a=5,int b=6,int c=7) // here we have given default argument when calling function if we won't pass any argument this default value will be set.
{
	return (a*b*c);
}
int main()
{
	cout<<mul()<<endl; // defult value will be set
	cout<<mul(6,8)<<endl; // first two value has given and third will be default.
	cout<<mul(6,8,10)<<endl; // all three value are given.
	return 0;
}
