#include<iostream>
using namespace std;
int sum(int i) // fun with one param.
{
	return i;
} 
int sum(int i,int j) // fun with same name but with two param.
{
	return i+j;
}

/* fun with same name and with two param. but differnt 				 return type but it will give error as in this fun and 			  previous fun signatures are same as in fun 				  overloading return type doesn't matter. 

float sum(int i,int j) 
{
	return i+j;
}*/
int sum(float i,float j)
{
	return i+j;
}
float sum(float i,float j,float k)
{
	return i+j+k;
}
int sum(int i,int j,int k)
{
	return i+j+k;
}
int main()
{
	cout<<"sum is"<<sum(4)<<endl;
	cout<<"sum is"<<sum(4,5)<<endl;
	cout<<"sum is"<<sum(4.5f,6.5f)<<endl; 
	// here i have passed f two say explicitly two compiler that i am 		calling fun which has float value as param and expcting output as a 		float value as if i will not pass f at last compile will give error as 		they expecting double data type.
	cout<<"sum is"<<sum(4.6f,6.5f,7.8f)<<endl; 
	cout<<"sum is"<<sum(4,5,6)<<endl;
	return 0;
}
