#include<iostream>
using namespace std;
template <typename T>
T sum(T n1,T n2)
{
	T rs;
	rs=n1+n2;
	return rs;
}
int main()
{
	int a=10,b=20;
	long A=20,B=30;
	cout<<"Sum of Int datatype:"<<sum(a,b)<<endl;
	cout<<"Sum of Long datatype:"<<sum(A,B)<<endl;
return 0;
}
