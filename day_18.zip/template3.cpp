#include<iostream>
using namespace std;
template <typename T>
class Addition
{
	public:
	
	T add(T n1,T n2)
{
	T res;
	res=n1+n2;
	return res;
}
};
int main()
{
	Addition<int> ob1;
	Addition<double> ob2;
	int a=10,b=20,c;
	double A=11.2,B=22.4,C;
	c=ob1.add(a,B);
	cout<<"Sum of int:"<<c<<endl;
	C=ob2.add(A,b);
	cout<<"Sum of long:"<<C<<endl;
return 0;
}
