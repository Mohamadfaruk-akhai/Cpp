#include<iostream>
using namespace std;
template <typename T,typename U>
void swap(T &n1,U &n2)
{
	T temp;
	temp=&n1;
	&n1=&n2;
	&n2=temp;
}
int main()
{
	int a=10,b=20;
	char A[10]="faruk",B[10]="Rahul";
	swap(a,b);
	cout<<"value after swap a="<<a<<" b="<<b<<endl;
	swap(A,B);
	cout<<"value after swap A="<<A<<" B="<<B<<endl;
return 0;
}
