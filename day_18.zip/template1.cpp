#include<iostream>
using namespace std;
template <typename T,typename U,typename V>
V multiply(T n1,U n2,V n3)
{
	T rs;
	rs=n1*n2;
	return rs;
}
int main()
{
	int a=10;
	double b=20.5;
	long c=15;
	double A=20.5,B=30;
	cout<<"Multiplication:"<<multiply(a,b,c)<<endl;
	cout<<" Multiplication:"<<multiply(A,B,c)<<endl;
return 0;
}
